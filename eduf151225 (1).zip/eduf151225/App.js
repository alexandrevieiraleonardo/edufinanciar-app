// PRIMEIRA LINHA OBRIGATÓRIA PARA GESTURE HANDLER (Expo / Android)
import "react-native-gesture-handler";

import React, { useEffect, useState } from "react";
import { View, ActivityIndicator, Platform } from "react-native";

import { NavigationContainer } from "@react-navigation/native";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { SafeAreaProvider, SafeAreaView } from "react-native-safe-area-context";

import AsyncStorage from "@react-native-async-storage/async-storage";

import MainTabs from "./src/navigation/MainTabs";
import LoginScreen from "./src/screens/LoginScreen";
import { UserContext } from "./src/contexts/UserContext";
import { COLORS } from "./src/data/colors";
import AsyncStorage from "@react-native-async-storage/async-storage";

useEffect(() => {
  AsyncStorage.clear()
    .then(() => console.log("AsyncStorage LIMPO"))
    .catch(console.error);
}, []);


const Stack = createNativeStackNavigator();

export default function App() {
  const [userEmail, setUserEmail] = useState(null);
  const [loading, setLoading] = useState(true);

  // Carrega usuário salvo
  useEffect(() => {
    (async () => {
      try {
        const storedEmail = await AsyncStorage.getItem("@user_email");
        if (storedEmail) {
          setUserEmail(storedEmail);
        }
      } catch (e) {
        console.log(e);
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  // Tela de loading inicial
  if (loading) {
    return (
      <View
        style={{
          flex: 1,
          alignItems: "center",
          justifyContent: "center",
          backgroundColor: "#fff",
        }}
      >
        <ActivityIndicator size="large" color={COLORS.primary} />
      </View>
    );
  }

  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <SafeAreaProvider>
        <SafeAreaView
          style={{ flex: 1, backgroundColor: "#fff" }}
          edges={Platform.OS === "android" ? ["top"] : ["top", "bottom"]}
        >
          <UserContext.Provider value={{ userEmail, setUserEmail }}>
            <NavigationContainer>
              <Stack.Navigator screenOptions={{ headerShown: false }}>
                {userEmail ? (
                  <Stack.Screen name="MainTabs" component={MainTabs} />
                ) : (
                  <Stack.Screen name="Login" component={LoginScreen} />
                )}
              </Stack.Navigator>
            </NavigationContainer>
          </UserContext.Provider>
        </SafeAreaView>
      </SafeAreaProvider>
    </GestureHandlerRootView>
  );
}
