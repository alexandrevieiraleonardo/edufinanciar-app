// src/utils/date.js

export function todayString() {
  return new Date().toISOString().slice(0, 10);
}

export function yesterdayString() {
  const d = new Date();
  d.setDate(d.getDate() - 1);
  return d.toISOString().slice(0, 10);
}
