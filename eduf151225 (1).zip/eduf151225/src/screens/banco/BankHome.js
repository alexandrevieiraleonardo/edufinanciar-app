// src/screens/banco/BankHome.js
import React, { useContext, useState } from "react";
import { ScrollView, Text, View, TextInput, Alert, TouchableOpacity } from "react-native";

import { BankContext } from "../../contexts/BankContext";
import { styles } from "../../styles/globalStyles";
import { COLORS } from "../../data/colors";

export default function BankHome({ navigation }) {
  const { accounts, setAccounts, currentId, setCurrentId } =
    useContext(BankContext);

  const [valor, setValor] = useState("");
  const [destino, setDestino] = useState(null);

  const conta = accounts[currentId];
  const outras = Object.values(accounts).filter((c) => c.id !== currentId);

  if (!conta) {
    navigation.replace("BankWelcome");
    return null;
  }

  function sair() {
    setCurrentId(null);
    navigation.replace("BankWelcome");
  }

  function enviarPix() {
    const v = Number(valor.replace(",", "."));
    if (!destino || !v || v <= 0) {
      Alert.alert("Erro", "Escolha destino e valor válido.");
      return;
    }

    if (conta.saldo < v) {
      Alert.alert("Saldo insuficiente");
      return;
    }

    setAccounts((prev) => {
      const origem = prev[currentId];
      const dest = prev[destino];
      const data = new Date().toLocaleString();

      return {
        ...prev,
        [currentId]: {
          ...origem,
          saldo: origem.saldo - v,
          extrato: [
            {
              id: Date.now(),
              tipo: "Pix enviado",
              descricao: `Para ${dest.apelido}`,
              valor: -v,
              data,
            },
            ...origem.extrato,
          ],
        },
        [destino]: {
          ...dest,
          saldo: dest.saldo + v,
          extrato: [
            {
              id: Date.now() + 1,
              tipo: "Pix recebido",
              descricao: `De ${origem.apelido}`,
              valor: v,
              data,
            },
            ...dest.extrato,
          ],
        },
      };
    });

    setValor("");
    setDestino(null);
    Alert.alert("Pix enviado com sucesso");
  }

  return (
    <ScrollView style={styles.container}>
      <View
        style={{
          flexDirection: "row",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <Text style={styles.title}>
          {conta.apelido} — {conta.bankName}
        </Text>
        <TouchableOpacity onPress={sair}>
          <Text style={{ color: COLORS.accentBlue }}>Trocar conta</Text>
        </TouchableOpacity>
      </View>

      <View
        style={{
          backgroundColor: COLORS.primary,
          padding: 16,
          borderRadius: 16,
          marginTop: 14,
        }}
      >
        <Text style={{ color: "#ecfdf5" }}>Saldo</Text>
        <Text
          style={{
            color: "#fff",
            fontSize: 26,
            fontWeight: "700",
          }}
        >
          R$ {conta.saldo.toFixed(2)}
        </Text>
      </View>

      <Text style={[styles.sub, { marginTop: 16 }]}>Enviar Pix</Text>

      {outras.map((c) => (
        <TouchableOpacity
          key={c.id}
          onPress={() => setDestino(c.id)}
          style={{
            padding: 10,
            borderRadius: 10,
            borderWidth: 1,
            borderColor:
              destino === c.id ? COLORS.primary : "#e5e7eb",
            marginTop: 8,
          }}
        >
          <Text>
            {c.apelido} — {c.bankName}
          </Text>
        </TouchableOpacity>
      ))}

      <TextInput
        style={styles.input}
        placeholder="Valor"
        keyboardType="numeric"
        value={valor}
        onChangeText={setValor}
      />

      <TouchableOpacity style={styles.btn} onPress={enviarPix}>
        <Text style={styles.btnText}>Enviar Pix</Text>
      </TouchableOpacity>

      <Text style={[styles.sub, { marginTop: 20 }]}>Extrato</Text>

      {conta.extrato.length === 0 && (
        <Text style={{ color: COLORS.muted }}>
          Nenhuma movimentação ainda.
        </Text>
      )}

      {conta.extrato.map((mov) => (
        <View
          key={mov.id}
          style={{
            backgroundColor: COLORS.card,
            padding: 10,
            borderRadius: 10,
            marginTop: 6,
            borderWidth: 1,
            borderColor: "#e5e7eb",
          }}
        >
          <Text style={{ fontWeight: "700" }}>{mov.tipo}</Text>
          <Text style={{ fontSize: 12, color: COLORS.muted }}>
            {mov.descricao}
          </Text>
          <Text
            style={{
              fontWeight: "700",
              color: mov.valor < 0 ? "#ef4444" : "#22c55e",
            }}
          >
            {mov.valor < 0 ? "-" : "+"} R${" "}
            {Math.abs(mov.valor).toFixed(2)}
          </Text>
        </View>
      ))}
    </ScrollView>
  );
}
