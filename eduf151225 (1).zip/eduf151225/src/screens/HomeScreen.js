// src/screens/HomeScreen.js
import React, { useContext } from "react";
import { View, Text, ScrollView, TouchableOpacity } from "react-native";

import { UserContext } from "../contexts/UserContext";
import { styles } from "../styles/globalStyles";
import AnimatedButton from "../components/AnimatedButton";
import { clearUser } from "../utils/storage";
import { COLORS } from "../data/colors";

export default function HomeScreen({ navigation }) {
  const { userEmail, setUserEmail } = useContext(UserContext);

  async function handleLogout() {
    await clearUser();
    setUserEmail(null);
  }

  return (
    <ScrollView style={styles.container}>
      <View
        style={{
          flexDirection: "row",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <Text style={styles.title}>Edufinanciar</Text>

        {userEmail && (
          <TouchableOpacity onPress={handleLogout}>
            <Text style={{ color: COLORS.accentBlue, fontWeight: "600" }}>
              Sair
            </Text>
          </TouchableOpacity>
        )}
      </View>

      <Text style={styles.sub}>
        Aprenda, pratique e teste seus conhecimentos financeiros.
      </Text>

      <AnimatedButton
        style={styles.card}
        onPress={() => navigation.navigate("Aprender")}
      >
        <Text style={styles.cardTitle}>📘 Aprender</Text>
        <Text style={styles.cardDesc}>
          Conteúdo por módulos sobre finanças.
        </Text>
      </AnimatedButton>

      <AnimatedButton
        style={styles.card}
        onPress={() => navigation.navigate("Praticar")}
      >
        <Text style={styles.cardTitle}>🏦 Praticar</Text>
        <Text style={styles.cardDesc}>
          Banco digital simulado para treino.
        </Text>
      </AnimatedButton>

      <AnimatedButton
        style={styles.card}
        onPress={() => navigation.navigate("Quiz")}
      >
        <Text style={styles.cardTitle}>🧪 Quiz</Text>
        <Text style={styles.cardDesc}>
          Teste seus conhecimentos.
        </Text>
      </AnimatedButton>

      <AnimatedButton
        style={styles.card}
        onPress={() => navigation.navigate("Progresso")}
      >
        <Text style={styles.cardTitle}>📊 Progresso</Text>
        <Text style={styles.cardDesc}>
          Acompanhe XP e streak.
        </Text>
      </AnimatedButton>
    </ScrollView>
  );
}
