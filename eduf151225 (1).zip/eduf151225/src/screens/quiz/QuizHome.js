// src/screens/quiz/QuizHome.js
import React from "react";
import { ScrollView, Text } from "react-native";

import { styles } from "../../styles/globalStyles";
import AnimatedButton from "../../components/AnimatedButton";

export default function QuizHome({ navigation }) {
  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Quiz</Text>

      <Text style={styles.sub}>
        Aqui você pode fazer o simulado geral com todas as perguntas.
      </Text>

      <AnimatedButton
        style={styles.card}
        onPress={() => navigation.navigate("QuizGeral")}
      >
        <Text style={styles.cardTitle}>🧪 Simulado Geral</Text>
        <Text style={styles.cardDesc}>
          Avaliação completa com perguntas de todos os módulos.
        </Text>
      </AnimatedButton>
    </ScrollView>
  );
}
