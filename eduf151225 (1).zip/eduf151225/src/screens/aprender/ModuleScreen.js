// src/screens/aprender/ModuleScreen.js
import React from "react";
import { ScrollView, Text, View, TouchableOpacity } from "react-native";
import { Ionicons } from "@expo/vector-icons";

import { styles } from "../../styles/globalStyles";
import { COLORS } from "../../data/colors";
import { MODULOS } from "../../data/modulos";
import { TOPICOS } from "../../data/topicos";
import AnimatedButton from "../../components/AnimatedButton";

export default function ModuleScreen({ route, navigation }) {
  const { moduleId } = route.params;

  const module = MODULOS.find((m) => m.id === moduleId);
  const topics = TOPICOS[moduleId] || [];

  return (
    <ScrollView style={styles.container}>
      <TouchableOpacity
        onPress={() => navigation.goBack()}
        style={{ flexDirection: "row", alignItems: "center", marginBottom: 8 }}
      >
        <Ionicons name="arrow-back" size={18} color={COLORS.muted} />
        <Text style={{ marginLeft: 6, color: COLORS.muted }}>Voltar</Text>
      </TouchableOpacity>

      <Text style={styles.title}>{module?.title ?? "Módulo"}</Text>
      <Text style={styles.sub}>
        Leia os tópicos abaixo e depois faça o quiz do módulo.
      </Text>

      {topics.map((t, index) => (
        <View
          key={index}
          style={{
            backgroundColor: COLORS.card,
            padding: 12,
            borderRadius: 10,
            marginTop: 10,
            borderWidth: 1,
            borderColor: "#e5e7eb",
          }}
        >
          <Text style={{ fontWeight: "700", marginBottom: 4 }}>
            {index + 1}. {t.title}
          </Text>
          <Text style={{ color: COLORS.muted, fontSize: 13 }}>
            {t.text}
          </Text>
        </View>
      ))}

      <AnimatedButton
        style={[styles.btn, { marginTop: 16 }]}
        onPress={() =>
          navigation.navigate("ModuleQuiz", { moduleId })
        }
      >
        <Text style={styles.btnText}>
          Fazer quiz deste módulo
        </Text>
      </AnimatedButton>
    </ScrollView>
  );
}
