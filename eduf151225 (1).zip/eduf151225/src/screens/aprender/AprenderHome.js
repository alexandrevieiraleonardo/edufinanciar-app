// src/screens/aprender/AprenderHome.js
import React from "react";
import { ScrollView, Text } from "react-native";

import { styles } from "../../styles/globalStyles";
import AnimatedButton from "../../components/AnimatedButton";
import { MODULOS } from "../../data/modulos";

export default function AprenderHome({ navigation }) {
  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Aprender</Text>
      <Text style={styles.sub}>
        Escolha um módulo para ler os tópicos e depois fazer o quiz.
      </Text>

      {MODULOS.map((m) => (
        <AnimatedButton
          key={m.id}
          style={styles.card}
          onPress={() =>
            navigation.navigate("Module", { moduleId: m.id })
          }
        >
          <Text style={styles.cardTitle}>{m.title}</Text>
          <Text style={styles.cardDesc}>
            Ver tópicos e quiz deste módulo
          </Text>
        </AnimatedButton>
      ))}
    </ScrollView>
  );
}
