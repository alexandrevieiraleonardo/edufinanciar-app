import React, { useRef } from "react";
import { Animated, Pressable } from "react-native";

export default function AnimatedButton({ onPress, style, children }) {
  const scale = useRef(new Animated.Value(1)).current;

  return (
    <Animated.View style={[{ transform: [{ scale }] }, style]}>
      <Pressable
        onPressIn={() =>
          Animated.spring(scale, { toValue: 0.96, useNativeDriver: true }).start()
        }
        onPressOut={() =>
          Animated.spring(scale, { toValue: 1, useNativeDriver: true }).start()
        }
        onPress={onPress}
        style={{ alignItems: "center", justifyContent: "center" }}
      >
        {children}
      </Pressable>
    </Animated.View>
  );
}
