// src/components/DicaAnimada.js
import React, { useEffect, useRef } from "react";
import { Animated, Text, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { COLORS } from "../data/colors";

export default function DicaAnimada({ icon, title, text, delay = 0 }) {
  const fade = useRef(new Animated.Value(0)).current;
  const scale = useRef(new Animated.Value(0.8)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fade, {
        toValue: 1,
        duration: 300,
        delay,
        useNativeDriver: true,
      }),
      Animated.spring(scale, {
        toValue: 1,
        delay,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  return (
    <Animated.View
      style={{
        opacity: fade,
        transform: [{ scale }],
        backgroundColor: COLORS.card,
        padding: 14,
        marginTop: 12,
        borderRadius: 12,
        borderWidth: 1,
        borderColor: "#e5e7eb",
      }}
    >
      <View style={{ flexDirection: "row", alignItems: "center" }}>
        <Ionicons name={icon} size={24} color={COLORS.accentBlue} />
        <Text style={{ fontSize: 16, fontWeight: "700", marginLeft: 10 }}>
          {title}
        </Text>
      </View>

      <Text style={{ marginTop: 6, color: COLORS.muted }}>
        {text}
      </Text>
    </Animated.View>
  );
}
