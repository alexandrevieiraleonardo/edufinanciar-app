// src/navigation/QuizStack.js
import React from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";

import QuizHome from "../screens/quiz/QuizHome";
import QuizGeral from "../screens/quiz/QuizGeral";

const Stack = createNativeStackNavigator();

export default function QuizStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="QuizHome" component={QuizHome} />
      <Stack.Screen name="QuizGeral" component={QuizGeral} />
    </Stack.Navigator>
  );
}
