// src/navigation/PraticarStack.js
import React, { useState } from "react";
import { createStackNavigator } from "@react-navigation/stack";

import { BankContext } from "../contexts/BankContext";
import { INITIAL_CONTAS } from "../data/contas";

import BankWelcome from "../screens/banco/BankWelcome";
import BankPin from "../screens/banco/BankPin";
import BankHome from "../screens/banco/BankHome";

const Stack = createStackNavigator();

export default function PraticarStack() {
  const [accounts, setAccounts] = useState(INITIAL_CONTAS);
  const [currentId, setCurrentId] = useState(null);

  return (
    <BankContext.Provider
      value={{ accounts, setAccounts, currentId, setCurrentId }}
    >
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        <Stack.Screen name="BankWelcome" component={BankWelcome} />
        <Stack.Screen name="BankPin" component={BankPin} />
        <Stack.Screen name="BankHome" component={BankHome} />
      </Stack.Navigator>
    </BankContext.Provider>
  );
}
