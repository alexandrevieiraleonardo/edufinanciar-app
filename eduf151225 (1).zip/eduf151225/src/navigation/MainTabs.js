// src/navigation/MainTabs.js
import React from "react";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { Ionicons } from "@expo/vector-icons";

import HomeScreen from "../screens/HomeScreen";
import ProgressoScreen from "../screens/ProgressoScreen";
import DicasDeSegurancaScreen from "../screens/DicasDeSegurancaScreen";

import AprenderStack from "./AprenderStack";
import QuizStack from "./QuizStack";
import PraticarStack from "./PraticarStack";

import { COLORS } from "../data/colors";

const Tab = createBottomTabNavigator();

export default function MainTabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: COLORS.primary,
        tabBarInactiveTintColor: COLORS.muted,
        tabBarStyle: {
          height: 64,
          paddingBottom: 6,
          paddingTop: 6,
          backgroundColor: COLORS.card,
          borderTopColor: "#e5e7eb",
        },
        tabBarIcon: ({ color, size }) => {
          const icons = {
            Início: "home",
            Aprender: "book",
            Praticar: "construct",
            Quiz: "help-circle",
            Progresso: "stats-chart",
            Dicas: "shield-checkmark",
          };

          return (
            <Ionicons
              name={icons[route.name]}
              size={size ?? 22}
              color={color}
            />
          );
        },
      })}
    >
      <Tab.Screen name="Início" component={HomeScreen} />
      <Tab.Screen name="Aprender" component={AprenderStack} />
      <Tab.Screen name="Praticar" component={PraticarStack} />
      <Tab.Screen name="Quiz" component={QuizStack} />
      <Tab.Screen name="Progresso" component={ProgressoScreen} />
      <Tab.Screen name="Dicas" component={DicasDeSegurancaScreen} />
    </Tab.Navigator>
  );
}
