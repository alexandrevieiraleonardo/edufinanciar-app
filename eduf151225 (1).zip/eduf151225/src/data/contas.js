// src/data/contas.js

export const INITIAL_CONTAS = {
  a: {
    id: "a",
    apelido: "Pessoa A",
    bankName: "Banco Verde",
    pin: "1111",
    saldo: 1200.0,
    extrato: [],
    chaves: {
      cpf: "111.111.111-11",
      email: "pessoa.a@edufinanciar.com",
      celular: "(81) 98888-0001",
    },
  },

  b: {
    id: "b",
    apelido: "Pessoa B",
    bankName: "Banco Azul",
    pin: "2222",
    saldo: 650.0,
    extrato: [],
    chaves: {
      cpf: "222.222.222-22",
      email: "pessoa.b@edufinanciar.com",
      celular: "(81) 98888-0002",
    },
  },

  c: {
    id: "c",
    apelido: "Pessoa C",
    bankName: "Banco Laranja",
    pin: "3333",
    saldo: 900.0,
    extrato: [],
    chaves: {
      cpf: "333.333.333-33",
      email: "pessoa.c@edufinanciar.com",
      celular: "(81) 98888-0003",
    },
  },

  d: {
    id: "d",
    apelido: "Pessoa D",
    bankName: "Banco Roxo",
    pin: "4444",
    saldo: 300.0,
    extrato: [],
    chaves: {
      cpf: "444.444.444-44",
      email: "pessoa.d@edufinanciar.com",
      celular: "(81) 98888-0004",
    },
  },
};
