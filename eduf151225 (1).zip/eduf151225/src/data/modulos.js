// src/data/modulos.js

export const MODULOS = [
  { id: "m1", title: "Bancos e Contas" },
  { id: "m2", title: "Cartões" },
  { id: "m3", title: "Apps de Pagamento" },
  { id: "m4", title: "Segurança Digital" },
  { id: "m5", title: "Orçamento" },
  { id: "m6", title: "Investimentos" },
];
