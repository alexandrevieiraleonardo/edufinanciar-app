// src/data/quiz.js

export const QUIZ = [
  // ===== MÓDULO 1 =====
  { id: "m1q1", module: "m1", question: "O que é conta corrente?", options: ["Conta para movimentações do dia a dia", "Tipo de investimento"], answer: 0 },
  { id: "m1q2", module: "m1", question: "Conta poupança serve para quê?", options: ["Guardar dinheiro", "Pagar contas automaticamente"], answer: 0 },
  { id: "m1q3", module: "m1", question: "O que é extrato bancário?", options: ["Histórico de movimentações", "Senha do banco"], answer: 0 },
  { id: "m1q4", module: "m1", question: "Pix é o quê?", options: ["Pagamento instantâneo", "Empréstimo bancário"], answer: 0 },
  { id: "m1q5", module: "m1", question: "Tarifa bancária é?", options: ["Cobrança por serviços", "Desconto automático"], answer: 0 },
  { id: "m1q6", module: "m1", question: "Conta digital precisa de agência física?", options: ["Nem sempre", "Sempre"], answer: 0 },
  { id: "m1q7", module: "m1", question: "Limite da conta é?", options: ["Crédito extra", "Saldo do banco"], answer: 0 },
  { id: "m1q8", module: "m1", question: "TED e DOC são?", options: ["Transferências bancárias", "Cartões"], answer: 0 },
  { id: "m1q9", module: "m1", question: "Saldo disponível é?", options: ["Valor que pode ser usado", "Saldo bloqueado"], answer: 0 },
  { id: "m1q10", module: "m1", question: "Boa prática bancária é?", options: ["Não compartilhar senha", "Enviar PIN por mensagem"], answer: 0 },

  // ===== MÓDULO 2 =====
  { id: "m2q1", module: "m2", question: "Cartão de crédito paga quando?", options: ["Depois, na fatura", "Na hora"], answer: 0 },
  { id: "m2q2", module: "m2", question: "Fatura é?", options: ["Resumo mensal do cartão", "Conta corrente"], answer: 0 },
  { id: "m2q3", module: "m2", question: "Parcelar compra pode?", options: ["Gerar juros", "Nunca alterar valor"], answer: 0 },
  { id: "m2q4", module: "m2", question: "Cartão virtual é?", options: ["Mais seguro para compras online", "Menos seguro"], answer: 0 },
  { id: "m2q5", module: "m2", question: "Rotativo do cartão é?", options: ["Juros por não pagar total", "Desconto"], answer: 0 },
  { id: "m2q6", module: "m2", question: "Limite do cartão é?", options: ["Valor máximo de uso", "Saldo do banco"], answer: 0 },
  { id: "m2q7", module: "m2", question: "Cashback é?", options: ["Devolução parcial", "Tarifa"], answer: 0 },
  { id: "m2q8", module: "m2", question: "Compartilhar dados do cartão?", options: ["Nunca", "Sempre"], answer: 0 },
  { id: "m2q9", module: "m2", question: "Cartão adicional serve para?", options: ["Outro usuário", "Diminuir limite"], answer: 0 },
  { id: "m2q10", module: "m2", question: "Senha do cartão deve ser?", options: ["Confidencial", "Compartilhada"], answer: 0 },

  // ===== MÓDULO 3 =====
  { id: "m3q1", module: "m3", question: "Pix funciona quando?", options: ["24 horas por dia", "Apenas horário comercial"], answer: 0 },
  { id: "m3q2", module: "m3", question: "Carteira digital é?", options: ["App de pagamento", "Banco físico"], answer: 0 },
  { id: "m3q3", module: "m3", question: "QR Code serve para?", options: ["Facilitar pagamento", "Criar senha"], answer: 0 },
  { id: "m3q4", module: "m3", question: "Chave Pix pode ser?", options: ["CPF, e-mail ou telefone", "Só CPF"], answer: 0 },
  { id: "m3q5", module: "m3", question: "Salvar comprovante é?", options: ["Boa prática", "Desnecessário"], answer: 0 },
  { id: "m3q6", module: "m3", question: "Boleto é?", options: ["Documento de cobrança", "Tipo de cartão"], answer: 0 },
  { id: "m3q7", module: "m3", question: "Agendar Pix é?", options: ["Possível", "Impossível"], answer: 0 },
  { id: "m3q8", module: "m3", question: "App bancário deve ser baixado?", options: ["Em loja oficial", "Em qualquer link"], answer: 0 },
  { id: "m3q9", module: "m3", question: "Transferência entre bancos hoje é?", options: ["Geralmente Pix", "Sempre DOC"], answer: 0 },
  { id: "m3q10", module: "m3", question: "Links suspeitos devem ser?", options: ["Ignorados", "Clicados"], answer: 0 },

 // ===== MÓDULO 4 =====

{ id: "m4q1", module: "m4", question: "Phishing é?", options: ["Golpe digital", "Tipo de conta"], answer: 0 },
{ id: "m4q2", module: "m4", question: "2FA serve para?", options: ["Aumentar segurança", "Diminuir acesso"], answer: 0 },
{ id: "m4q3", module: "m4", question: "Wi-Fi público é seguro para banco?", options: ["Não", "Sim"], answer: 0 },
{ id: "m4q4", module: "m4", question: "Senha forte deve ter?", options: ["Letras, números e símbolos", "Só números"], answer: 0 },
{ id: "m4q5", module: "m4", question: "Atualizar apps é?", options: ["Importante", "Opcional"], answer: 0 },
{ id: "m4q6", module: "m4", question: "Compartilhar código do banco?", options: ["Nunca", "Sempre"], answer: 0 },
{ id: "m4q7", module: "m4", question: "Verificar remetente do e-mail?", options: ["Sim", "Não"], answer: 0 },
{ id: "m4q8", module: "m4", question: "Instalar apps desconhecidos?", options: ["Não", "Sim"], answer: 0 },
{ id: "m4q9", module: "m4", question: "Bloquear tela é ...", options: ["Fundamental", "Opcional"], answer: 0 },
{ id: "m4q10", module: "m4", question: "Código de verificação vence rápido?", options: ["Sim", "Não"], answer: 0 },

  // ===== MÓDULO 5 =====

  { id: "m5q1", module: "m5", question: "Orçamento é?", options: ["Planejamento financeiro", "Tipo de investimento"], answer: 0 },
  { id: "m5q2", module: "m5", question: "Reserva de emergência serve para?", options: ["Imprevistos", "Compras por impulso"], answer: 0 },
  { id: "m5q3", module: "m5", question: "50/30/20 é?", options: ["Método de gastos", "Tipo de conta"], answer: 0 },
  { id: "m5q4", module: "m5", question: "Anotar gastos ajuda?", options: ["Sim", "Não"], answer: 0 },
  { id: "m5q5", module: "m5", question: "Revisar orçamento é?", options: ["Importante", "Inútil"], answer: 0 },
  { id: "m5q6", module: "m5", question: "Automatizar poupança é ...", options: ["Planejamento financeiro", "Tipo de investimento"], answer: 0 },
  { id: "m5q7", module: "m5", question: "Gastos fixos são ...", options: ["Aluguel, contas", "Compras ocasionais"], answer: 0 },
  { id: "m5q8", module: "m5", question: "Planejar meta financeira?", options: ["Sim", "Não"], answer: 0 },
  { id: "m5q9", module: "m5", question: "Controlar pequenos gastos?", options: ["Importante", "Sem importância"], answer: 0 },
  { id: "m5q10", module: "m5", question: "Revisar orçamento mensal?", options: ["Sim", "Não"], answer: 0 },

  // ===== MÓDULO 6 =====
  { id: "m6q1", module: "m6", question: "Renda fixa é?", options: ["Mais previsível", "Sempre arriscada"], answer: 0 },
  { id: "m6q2", module: "m6", question: "Tesouro Direto é?", options: ["Título público", "Conta corrente"], answer: 0 },
  { id: "m6q3", module: "m6", question: "Diversificar investimentos é?", options: ["Reduzir riscos", "Aumentar riscos"], answer: 0 },
  { id: "m6q4", module: "m6", question: "Liquidez significa?", options: ["Facilidade de resgate", "Lucro alto"], answer: 0 },
  { id: "m6q5", module: "m6", question: "Investir todo mês é?", options: ["Boa prática", "Errado"], answer: 0 },
  { id: "m6q6", module: "m6", question: "Investir longo prazo?", options: ["Pode reduzir risco", "Sempre ruim"], answer: 0 },
  { id: "m6q7", module: "m6", question: "Taxa de administração é ...", options: ["Cobrança de fundos", "Nome de banco"], answer: 0 },
  { id: "m6q8", module: "m6", question: "Benchmark serve para ...", options: ["Comparar desempenho", "Aumentar riscos"], answer: 0 },
  { id: "m6q9", module: "m6", question: "ETFs replicam ...", options: ["Índices", "Contas"], answer: 0 },
  { id: "m6q10", module: "m6", question: "Aporte periódico é ...", options: ["Investimento regular", "Despesas"], answer: 0 },
];
