// src/data/topicos.js
// =========================================
// TOPICOS
// =========================================
export const TOPICOS= {
  m1: [
    { title: "Conta corrente", text: "Para movimentações do dia a dia." },
    { title: "Conta poupança", text: "Para guardar dinheiro e render." },
    { title: "Agência & conta", text: "Identificadores bancários." },
    { title: "Extrato", text: "Histórico de movimentações." },
    { title: "Saldo disponível", text: "Valor livre após bloqueios." },
    { title: "Tarifas", text: "Cobranças do banco." },
    { title: "Conta digital", text: "Movimentação pelo celular." },
    { title: "TED, DOC, Pix", text: "Formas de transferências." },
    { title: "Limite", text: "Cheque especial ou crédito." },
    { title: "Cuidados", text: "Nunca compartilhe senhas." },
  ],

  m2: [
    { title: "Cartão débito", text: "Paga usando saldo." },
    { title: "Cartão crédito", text: "Paga depois, via fatura." },
    { title: "Fatura", text: "Documento mensal de consumo." },
    { title: "Limite", text: "Valor máximo disponível." },
    { title: "Parcelamento", text: "Pode ter juros altos." },
    { title: "Rotativo", text: "Juros altíssimos." },
    { title: "Cartão adicional", text: "Para familiares." },
    { title: "Cartão virtual", text: "Mais seguro online." },
    { title: "Pontos & Cashback", text: "Benefícios." },
    { title: "Segurança", text: "Evite compartilhar dados." },
  ],

  m3: [
    { title: "Carteira digital", text: "Apps como PicPay." },
    { title: "Pix 24/7", text: "Funciona sempre." },
    { title: "Chaves Pix", text: "CPF, e-mail, celular." },
    { title: "QR Code", text: "Pagamento rápido." },
    { title: "Boletos", text: "Linha digitável e vencimento." },
    { title: "Comprovantes", text: "Importante guardar." },
    { title: "Transferências", text: "Pix é a mais utilizada." },
    { title: "Agendamentos", text: "Pagamentos programados." },
    { title: "Limites Pix", text: "Por segurança." },
    { title: "Fraudes", text: "Cuidado com links falsos." },
  ],

  m4: [
    { title: "Phishing", text: "Golpes por mensagens falsas." },
    { title: "Senhas fortes", text: "Misture letras, números e símbolos." },
    { title: "Autenticação 2FA", text: "Proteção adicional." },
    { title: "Wi-Fi público", text: "Evite bancos nessas redes." },
    { title: "Atualizações", text: "Corrige falhas." },
    { title: "Golpes telefônicos", text: "Bancos não pedem senha." },
    { title: "Verificação de remetente", text: "Evita phishing." },
    { title: "Apps oficiais", text: "Evite APK desconhecido." },
    { title: "Tela bloqueada", text: "Use PIN ou biometria." },
    { title: "Códigos SMS", text: "Nunca compartilhe." },
  ],

  m5: [
    { title: "Orçamento", text: "Plano financeiro." },
    { title: "Mapa de gastos", text: "Registre seus gastos." },
    { title: "Fixos & Variáveis", text: "Organize despesas." },
    { title: "50/30/20", text: "Regra clássica." },
    { title: "Reserva", text: "3–6 meses de gastos." },
    { title: "Cortes", text: "Elimine desperdícios." },
    { title: "Metas", text: "Objetivos financeiros." },
    { title: "Automatização", text: "Ajuda na disciplina." },
    { title: "Revisão", text: "Ajuste mensal." },
    { title: "Pequenos gastos", text: "Eles somam!" },
  ],

  m6: [
    { title: "Renda fixa", text: "Investimento previsível." },
    { title: "Tesouro Direto", text: "Títulos públicos." },
    { title: "Renda variável", text: "Oscila mais." },
    { title: "Diversificação", text: "Reduz riscos." },
    { title: "Liquidez", text: "Quão rápido resgata." },
    { title: "Prazo", text: "Curto, médio e longo." },
    { title: "Taxas", text: "Custos dos investimentos." },
    { title: "Perfil", text: "Conservador, moderado, arrojado." },
    { title: "ETFs", text: "Fundos de índice." },
    { title: "Aportes", text: "Invista sempre." },
  ],
};
