// src/utils/storage.js
import AsyncStorage from "@react-native-async-storage/async-storage";

// ===== USUÁRIO =====
export async function getUserEmail() {
  return AsyncStorage.getItem("@user_email");
}

export async function setUserEmail(email) {
  return AsyncStorage.setItem("@user_email", email);
}

export async function clearUser() {
  return AsyncStorage.multiRemove([
    "@user_email",
    "@user_name",
    "@app_xp",
    "@app_streak",
    "@app_last_quiz",
    "@quiz_history",
  ]);
}

// ===== PROGRESSO =====
export async function getXp() {
  const v = await AsyncStorage.getItem("@app_xp");
  return v ? Number(v) : 0;
}

export async function setXp(xp) {
  return AsyncStorage.setItem("@app_xp", String(xp));
}

export async function getStreak() {
  const v = await AsyncStorage.getItem("@app_streak");
  return v ? Number(v) : 0;
}

export async function setStreak(streak) {
  return AsyncStorage.setItem("@app_streak", String(streak));
}

export async function getLastQuizDate() {
  return AsyncStorage.getItem("@app_last_quiz");
}

export async function setLastQuizDate(date) {
  return AsyncStorage.setItem("@app_last_quiz", date);
}

// ===== HISTÓRICO DE QUIZ =====
export async function getQuizHistory() {
  const raw = await AsyncStorage.getItem("@quiz_history");
  return raw ? JSON.parse(raw) : [];
}

export async function setQuizHistory(history) {
  return AsyncStorage.setItem("@quiz_history", JSON.stringify(history));
}
