// src/screens/banco/BankWelcome.js
import React, { useContext } from "react";
import { ScrollView, Text } from "react-native";

import { BankContext } from "../../contexts/BankContext";
import { styles } from "../../styles/globalStyles";
import AnimatedButton from "../../components/AnimatedButton";

export default function BankWelcome({ navigation }) {
  const { accounts } = useContext(BankContext);
  const contas = Object.values(accounts);

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Banco Simulado</Text>
      <Text style={styles.sub}>
        Escolha uma conta para treinar e depois entre com o PIN.
      </Text>

      {contas.map((acc) => (
        <AnimatedButton
          key={acc.id}
          style={styles.card}
          onPress={() =>
            navigation.navigate("BankPin", { accountId: acc.id })
          }
        >
          <Text style={styles.cardTitle}>
            {acc.apelido} — {acc.bankName}
          </Text>
          <Text style={styles.cardDesc}>
            PIN padrão: {acc.pin}
          </Text>
        </AnimatedButton>
      ))}
    </ScrollView>
  );
}
