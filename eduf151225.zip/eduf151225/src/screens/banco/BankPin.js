// src/screens/banco/BankPin.js
import React, { useContext, useState } from "react";
import { View, Text, TextInput, Alert, TouchableOpacity } from "react-native";
import { Ionicons } from "@expo/vector-icons";

import { BankContext } from "../../contexts/BankContext";
import { styles } from "../../styles/globalStyles";
import { COLORS } from "../../data/colors";

export default function BankPin({ route, navigation }) {
  const { accountId } = route.params;
  const { accounts, setCurrentId } = useContext(BankContext);
  const [pin, setPin] = useState("");

  const conta = accounts[accountId];

  if (!conta) {
    return (
      <View style={[styles.container, { justifyContent: "center" }]}>
        <Text style={styles.title}>Conta não encontrada</Text>
      </View>
    );
  }

  function handleLogin() {
    if (pin === conta.pin) {
      setCurrentId(accountId);
      setPin("");
      navigation.replace("BankHome");
    } else {
      Alert.alert("PIN incorreto", "Digite o PIN correto.");
    }
  }

  return (
    <View style={styles.container}>
      <TouchableOpacity
        onPress={() => navigation.goBack()}
        style={{ flexDirection: "row", alignItems: "center", marginBottom: 8 }}
      >
        <Ionicons name="arrow-back" size={18} color={COLORS.muted} />
        <Text style={{ marginLeft: 6, color: COLORS.muted }}>Voltar</Text>
      </TouchableOpacity>

      <Text style={styles.title}>Login bancário</Text>
      <Text style={styles.sub}>
        {conta.apelido} — {conta.bankName}
      </Text>

      <TextInput
        style={styles.input}
        placeholder="PIN (4 dígitos)"
        secureTextEntry
        keyboardType="numeric"
        maxLength={4}
        value={pin}
        onChangeText={setPin}
      />

      <TouchableOpacity style={styles.btn} onPress={handleLogin}>
        <Text style={styles.btnText}>Entrar</Text>
      </TouchableOpacity>
    </View>
  );
}
