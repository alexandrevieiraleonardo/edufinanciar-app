import React, { useEffect, useState, useContext } from "react";
import { View, Text, TouchableOpacity, Alert } from "react-native";

import { styles } from "../../styles/globalStyles";
import { COLORS } from "../../data/colors";
import { QUIZ } from "../../data/quiz";
import { UserContext } from "../../contexts/UserContext";
import {
  getXp,
  setXp,
  getStreak,
  setStreak,
  getLastQuizDate,
  setLastQuizDate,
  getQuizHistory,
  setQuizHistory,
} from "../../utils/storage";
import { todayString, yesterdayString } from "../../utils/date";

export default function ModuleQuizScreen({ route, navigation }) {
  const { moduleId } = route.params;
  const { userEmail } = useContext(UserContext);

  const questions = QUIZ.filter((q) => q.module === moduleId);

  const [index, setIndex] = useState(0);
  const [selected, setSelected] = useState(null);
  const [score, setScore] = useState(0);
  const [finished, setFinished] = useState(false);

  useEffect(() => {
    setIndex(0);
    setSelected(null);
    setScore(0);
    setFinished(false);
  }, [moduleId]);

  async function handleAnswer(i) {
    if (selected !== null) return;

    setSelected(i);
    const correct = questions[index].answer === i;
    if (correct) setScore((s) => s + 1);

    setTimeout(async () => {
      setSelected(null);

      if (index + 1 < questions.length) {
        setIndex((v) => v + 1);
      } else {
        setFinished(true);
        const acertos = score + (correct ? 1 : 0);
        const earnedXp = acertos * 10;

        // XP
        const currentXp = await getXp();
        await setXp(currentXp + earnedXp);

        // Streak
        const last = await getLastQuizDate();
        const today = todayString();
        const yesterday = yesterdayString();
        let streak = 1;

        if (last === today) {
          streak = await getStreak();
        } else if (last === yesterday) {
          streak = (await getStreak()) + 1;
        }

        await setStreak(streak);
        await setLastQuizDate(today);

        // Histórico
        const history = await getQuizHistory();
        const newEntry = {
          id: Date.now(),
          email: userEmail || "anon",
          kind: "modulo",
          module: moduleId,
          correct: acertos,
          total: questions.length,
          created_at: new Date().toISOString(),
        };
        await setQuizHistory([newEntry, ...history].slice(0, 10));

        Alert.alert(
          "Quiz finalizado",
          `Acertos: ${acertos}/${questions.length}\nXP ganho: ${earnedXp}\nStreak: ${streak} dia(s)`
        );
      }
    }, 400);
  }

  if (!questions.length) {
    return (
      <View style={styles.container}>
        <Text style={styles.title}>Quiz</Text>
        <Text>Nenhuma pergunta encontrada.</Text>
      </View>
    );
  }

  if (finished) {
    return (
      <View style={styles.container}>
        <Text style={styles.title}>Resultado</Text>
        <Text style={{ marginTop: 12 }}>
          Acertos: {score} / {questions.length}
        </Text>

        <TouchableOpacity
          style={styles.btn}
          onPress={() => navigation.goBack()}
        >
          <Text style={styles.btnText}>Voltar</Text>
        </TouchableOpacity>
      </View>
    );
  }

  const q = questions[index];

  return (
    <View style={styles.container}>
      <Text style={{ color: COLORS.muted }}>
        Pergunta {index + 1} / {questions.length}
      </Text>

      <Text style={{ fontSize: 18, marginTop: 8 }}>
        {q.question}
      </Text>

      {q.options.map((opt, i) => {
        let bg = "#fff";
        if (selected !== null) {
          if (i === q.answer) bg = "#bbf7d0";
          else if (i === selected) bg = "#fecaca";
        }

        return (
          <TouchableOpacity
            key={i}
            onPress={() => handleAnswer(i)}
            style={{
              backgroundColor: bg,
              padding: 12,
              borderRadius: 10,
              marginTop: 10,
              borderWidth: 1,
              borderColor: "#e5e7eb",
            }}
          >
            <Text>{opt}</Text>
          </TouchableOpacity>
        );
      })}
    </View>
  );
}

