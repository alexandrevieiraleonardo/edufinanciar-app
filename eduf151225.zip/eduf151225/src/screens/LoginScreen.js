// src/screens/LoginScreen.js
import React, { useContext, useState } from "react";
import {
  View,
  Text,
  TextInput,
  Alert,
} from "react-native";

import { UserContext } from "../contexts/UserContext";
import { styles } from "../styles/globalStyles";
import AnimatedButton from "../components/AnimatedButton";
import { setUserEmail as saveUserEmail } from "../utils/storage";

export default function LoginScreen() {
  const { setUserEmail } = useContext(UserContext);
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleLogin() {
    if (!email.trim()) {
      Alert.alert("Aviso", "Digite seu e-mail.");
      return;
    }

    setLoading(true);
    try {
      const safe = email.trim().toLowerCase();
      await saveUserEmail(safe);
      setUserEmail(safe);
    } catch (e) {
      Alert.alert("Erro", "Não foi possível salvar o usuário.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <View style={[styles.container, { justifyContent: "center" }]}>
      {/* LOGO: CÍRCULO VERDE COM "Ef" */}
      <View style={{ alignItems: "center", marginBottom: 24 }}>
        <View
          style={{
            width: 96,
            height: 96,
            borderRadius: 48,
            backgroundColor: "#16a34a",
            alignItems: "center",
            justifyContent: "center",
            marginBottom: 12,
          }}
        >
          <Text
            style={{
              color: "#f9fafb",
              fontSize: 32,
              fontWeight: "800",
            }}
          >
            Ef
          </Text>
        </View>

        <Text style={styles.title}>Edufinanciar</Text>

        <Text style={styles.sub}>
          Entre com seu e-mail para continuar
        </Text>
      </View>

      {/* INPUT */}
      <TextInput
        style={styles.input}
        placeholder="email@exemplo.com"
        keyboardType="email-address"
        autoCapitalize="none"
        value={email}
        onChangeText={setEmail}
      />

      {/* BOTÃO */}
      <AnimatedButton style={styles.btn} onPress={handleLogin}>
        <Text style={styles.btnText}>
          {loading ? "Entrando..." : "Entrar"}
        </Text>
      </AnimatedButton>
    </View>
  );
}
