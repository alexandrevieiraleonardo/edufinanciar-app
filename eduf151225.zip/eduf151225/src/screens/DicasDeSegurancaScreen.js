// src/screens/DicasDeSegurancaScreen.js
import React from "react";
import { ScrollView, Text } from "react-native";

import { styles } from "../styles/globalStyles";
import DicaAnimada from "../components/DicaAnimada";

export default function DicasDeSegurancaScreen() {
  const dicas = [
    {
      icon: "shield-checkmark",
      title: "Use senhas fortes",
      text: "Misture letras maiúsculas, minúsculas, números e símbolos.",
    },
    {
      icon: "phone-portrait",
      title: "Ative autenticação em dois fatores",
      text: "O 2FA adiciona uma camada extra de segurança às suas contas.",
    },
    {
      icon: "wifi",
      title: "Evite Wi-Fi público",
      text: "Prefira dados móveis ao acessar apps bancários.",
    },
    {
      icon: "alert-circle",
      title: "Desconfie de mensagens urgentes",
      text: "Golpistas usam urgência para enganar você.",
    },
    {
      icon: "lock-closed",
      title: "Nunca compartilhe códigos",
      text: "Códigos enviados por SMS ou app são pessoais.",
    },
  ];

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Dicas de Segurança</Text>

      {dicas.map((dica, index) => (
        <DicaAnimada
          key={index}
          icon={dica.icon}
          title={dica.title}
          text={dica.text}
          delay={index * 120}
        />
      ))}
    </ScrollView>
  );
}
