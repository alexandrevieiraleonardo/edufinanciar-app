// ---------- PROGRESSO (Estilo Duolingo melhorado) ----------
function ProgressoScreen() {
  const { userEmail } = useContext(UserContext);

  const [xp, setXp] = useState(0);
  const [streak, setStreak] = useState(0);
  const [last, setLast] = useState(null);
  const [logs, setLogs] = useState([]);

  const progressAnim = useRef(new Animated.Value(0)).current;
  const medalScale = useRef(new Animated.Value(0)).current;

  // ---------------- MEDALHAS ----------------
  function getMedalInfo(xpTotal) {
    if (xpTotal >= 1000) {
      return { icon: "💎", label: "Medalha Diamante", barColor: "#22d3ee", next: null };
    }
    if (xpTotal >= 600) {
      return { icon: "🥇", label: "Medalha Ouro", barColor: "#facc15", next: "Diamante (1000 XP)" };
    }
    if (xpTotal >= 300) {
      return { icon: "🥈", label: "Medalha Prata", barColor: "#9ca3af", next: "Ouro (600 XP)" };
    }
    if (xpTotal >= 100) {
      return { icon: "🥉", label: "Medalha Bronze", barColor: "#fb923c", next: "Prata (300 XP)" };
    }
    return { icon: "🎯", label: "Iniciante", barColor: COLORS.primary, next: "Bronze (100 XP)" };
  }

  // ---------------- LOAD DADOS ----------------
  useEffect(() => {
    (async () => {
      try {
        const cur = await AsyncStorage.getItem("@app_xp");
        const s = await AsyncStorage.getItem("@app_streak");
        const l = await AsyncStorage.getItem("@app_last_quiz");

        const xpNum = Number(cur) || 0;
        setXp(xpNum);
        setStreak(Number(s) || 0);
        setLast(typeof l === "string" ? l : null);

        const resto = xpNum % 100;
        const xpNivelDisplay = xpNum === 0 ? 0 : resto === 0 ? 100 : resto;

        progressAnim.setValue(0);
        Animated.timing(progressAnim, {
          toValue: xpNivelDisplay,
          duration: 700,
          useNativeDriver: false,
        }).start();

        medalScale.setValue(0);
        Animated.spring(medalScale, {
          toValue: 1,
          useNativeDriver: true,
        }).start();

        const historyRaw = await AsyncStorage.getItem("@quiz_history");
        const history = historyRaw ? JSON.parse(historyRaw) : [];

        const safeHistory = Array.isArray(history) ? history : [];

        const filtered = userEmail
          ? safeHistory.filter(h => h?.email === userEmail)
          : safeHistory;

        setLogs(filtered);
      } catch (e) {
        console.error("Erro Progresso:", e);
        setLogs([]);
      }
    })();
  }, [userEmail]);

  // ---------------- CÁLCULOS ----------------
  const level = Math.floor(xp / 100) + 1;
  const medalInfo = getMedalInfo(xp);

  const resto = xp % 100;
  const xpNivelDisplay = xp === 0 ? 0 : resto === 0 ? 100 : resto;
  const faltaProxNivel = xp === 0 ? 100 : 100 - xpNivelDisplay;

  const barWidth = progressAnim.interpolate({
    inputRange: [0, 100],
    outputRange: ["0%", "100%"],
  });

  // ---------------- RENDER ----------------
  return (
    <ScrollView style={[styles.container, { backgroundColor: COLORS.bg }]}>
      <Text style={styles.title}>Progresso</Text>

      {/* CARD XP */}
      <View style={{ backgroundColor: COLORS.card, borderRadius: 16, padding: 16, marginTop: 12 }}>
        <View style={{ flexDirection: "row", alignItems: "center" }}>
          <Animated.View
            style={{
              width: 64,
              height: 64,
              borderRadius: 999,
              backgroundColor: COLORS.primaryLight,
              alignItems: "center",
              justifyContent: "center",
              transform: [{ scale: medalScale }],
            }}
          >
            <Text style={{ fontSize: 32 }}>{medalInfo.icon}</Text>
          </Animated.View>

          <View style={{ marginLeft: 12, flex: 1 }}>
            <Text style={{ fontSize: 18, fontWeight: "700", color: COLORS.text }}>
              Nível {Number(level)}
            </Text>
            <Text style={{ color: COLORS.muted }}>{String(medalInfo.label)}</Text>
            <Text style={{ color: COLORS.muted, fontSize: 12 }}>
              XP total: {Number(xp)}
            </Text>
          </View>
        </View>

        <View style={{ marginTop: 14, height: 18, backgroundColor: "#e5e7eb", borderRadius: 999 }}>
          <Animated.View
            style={{
              height: "100%",
              width: barWidth,
              backgroundColor: medalInfo.barColor,
            }}
          />
        </View>

        <View style={{ flexDirection: "row", justifyContent: "space-between", marginTop: 4 }}>
          <Text style={{ fontSize: 12, color: COLORS.muted }}>
            {Number(xpNivelDisplay)} / 100 XP
          </Text>
          <Text style={{ fontSize: 12, color: COLORS.muted }}>
            Faltam {Number(faltaProxNivel)} XP
          </Text>
        </View>
      </View>

      {/* HISTÓRICO */}
      <Text style={[styles.sub, { marginTop: 20 }]}>Histórico recente de quizzes</Text>

      {logs.length === 0 && (
        <Text style={{ color: COLORS.muted }}>
          Nenhum registro ainda. Faça um quiz para aparecer aqui.
        </Text>
      )}

      {logs.map((log, index) => {
        const mod = MODULOS?.find(m => m?.id === log?.module);

        const moduleTitle =
          log?.module === "GERAL"
            ? "Simulado Geral"
            : mod?.title ??
              (typeof log?.module === "string" ? log.module : "Módulo desconhecido");

        const tipoLabel = log?.kind === "geral" ? "Simulado Geral" : "Quiz por módulo";
        const icon = log?.kind === "geral" ? "🧪" : "📘";

        return (
          <View
            key={String(log?.id ?? index)}
            style={{
              backgroundColor: "#f5f3ff",
              padding: 10,
              borderRadius: 10,
              marginTop: 8,
              borderLeftWidth: 4,
              borderLeftColor: COLORS.primary,
            }}
          >
            <Text style={{ fontWeight: "700", color: COLORS.text }}>
              {icon} {String(moduleTitle)}
            </Text>

            <Text style={{ color: COLORS.muted, fontSize: 12 }}>
              {String(tipoLabel)} — Acertos: {Number(log?.correct) || 0}/{Number(log?.total) || 0}
            </Text>

            <Text style={{ color: COLORS.muted, fontSize: 11 }}>
              {log?.created_at ? new Date(log.created_at).toLocaleString() : ""}
            </Text>
          </View>
        );
      })}
    </ScrollView>
  );
}
