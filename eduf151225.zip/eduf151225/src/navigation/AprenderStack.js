// src/navigation/AprenderStack.js
import React from "react";
import { createStackNavigator } from "@react-navigation/stack";

import AprenderHome from "../screens/aprender/AprenderHome";
import ModuleScreen from "../screens/aprender/ModuleScreen";
import ModuleQuizScreen from "../screens/aprender/ModuleQuizScreen";

const Stack = createStackNavigator();

export default function AprenderStack() {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="AprenderHome" component={AprenderHome} />
      <Stack.Screen name="Module" component={ModuleScreen} />
      <Stack.Screen name="ModuleQuiz" component={ModuleQuizScreen} />
    </Stack.Navigator>
  );
}

