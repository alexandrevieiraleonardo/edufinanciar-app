// src/styles/globalStyles.js
import { StyleSheet } from "react-native";
import { COLORS } from "../data/colors";

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 18,
    paddingTop: 12,
    backgroundColor: COLORS.bg,
  },

  title: {
    fontSize: 22,
    fontWeight: "700",
    color: COLORS.text,
  },

  sub: {
    marginTop: 12,
    fontSize: 13,
    color: COLORS.muted,
  },

  card: {
    backgroundColor: COLORS.card,
    padding: 14,
    borderRadius: 12,
    marginTop: 12,
    borderWidth: 1,
    borderColor: "#e5e7eb",
  },

  cardTitle: {
    fontWeight: "700",
    color: COLORS.text,
    fontSize: 16,
  },

  cardDesc: {
    marginTop: 6,
    color: COLORS.muted,
    fontSize: 13,
  },

  input: {
    marginTop: 8,
    padding: 12,
    borderWidth: 1,
    borderColor: "#e5e7eb",
    borderRadius: 8,
    backgroundColor: "#fff",
  },

  btn: {
    backgroundColor: COLORS.primary,
    padding: 12,
    marginTop: 12,
    borderRadius: 999,
    alignItems: "center",
  },

  btnText: {
    color: "#fff",
    fontWeight: "700",
  },
});
