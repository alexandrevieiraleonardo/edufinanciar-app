// src/contexts/BankContext.js
import { createContext } from "react";

export const BankContext = createContext({
  accounts: {},
  setAccounts: () => {},
  currentId: null,
  setCurrentId: () => {},
});

