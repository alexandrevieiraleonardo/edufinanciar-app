// PRIMEIRA LINHA — OBRIGATÓRIA PARA iOS & ANDROID (Gesture Handler)
import "react-native-gesture-handler";

import React, {
  useEffect,
  useState,
  useRef,
  useContext,
  createContext,
} from "react";

import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  TextInput,
  Alert,
  Animated,
  Pressable,
  ActivityIndicator,
} from "react-native";

import AsyncStorage from "@react-native-async-storage/async-storage";

import { NavigationContainer } from "@react-navigation/native";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { createNativeStackNavigator } from "@react-navigation/native-stack";

import { GestureHandlerRootView } from "react-native-gesture-handler";
import { Ionicons } from "@expo/vector-icons";

// =========================================
// CONTEXTOS
// =========================================

const UserContext = createContext({
  userEmail: null,
  setUserEmail: () => {},
});

const BankContext = createContext(null);

// =========================================
// CORES
// =========================================

const COLORS = {
  primary: "#22c55e",
  primaryDark: "#16a34a",
  primaryLight: "#dcfce7",
  bg: "#f9fafb",
  card: "#ffffff",
  text: "#111827",
  muted: "#6b7280",
  accentBlue: "#3b82f6",
};

// =========================================
// MODULOS (SEÇÕES DE APRENDIZADO)
// =========================================

const MODULOS = [
  { id: "m1", title: "Bancos e Contas" },
  { id: "m2", title: "Cartões" },
  { id: "m3", title: "Apps de Pagamento" },
  { id: "m4", title: "Segurança Digital" },
  { id: "m5", title: "Orçamento" },
  { id: "m6", title: "Investimentos" },
];

// =========================================
// TOPICOS
// =========================================

const TOPICOS = {
  m1: [
    { title: "Conta corrente", text: "Para movimentações do dia a dia." },
    { title: "Conta poupança", text: "Para guardar dinheiro e render." },
    { title: "Agência & conta", text: "Identificadores bancários." },
    { title: "Extrato", text: "Histórico de movimentações." },
    { title: "Saldo disponível", text: "Valor livre após bloqueios." },
    { title: "Tarifas", text: "Cobranças do banco." },
    { title: "Conta digital", text: "Movimentação pelo celular." },
    { title: "TED, DOC, Pix", text: "Formas de transferências." },
    { title: "Limite", text: "Cheque especial ou crédito." },
    { title: "Cuidados", text: "Nunca compartilhe senhas." },
  ],

  m2: [
    { title: "Cartão débito", text: "Paga usando saldo." },
    { title: "Cartão crédito", text: "Paga depois, via fatura." },
    { title: "Fatura", text: "Documento mensal de consumo." },
    { title: "Limite", text: "Valor máximo disponível." },
    { title: "Parcelamento", text: "Pode ter juros altos." },
    { title: "Rotativo", text: "Juros altíssimos." },
    { title: "Cartão adicional", text: "Para familiares." },
    { title: "Cartão virtual", text: "Mais seguro online." },
    { title: "Pontos & Cashback", text: "Benefícios." },
    { title: "Segurança", text: "Evite compartilhar dados." },
  ],

  m3: [
    { title: "Carteira digital", text: "Apps como PicPay." },
    { title: "Pix 24/7", text: "Funciona sempre." },
    { title: "Chaves Pix", text: "CPF, e-mail, celular." },
    { title: "QR Code", text: "Pagamento rápido." },
    { title: "Boletos", text: "Linha digitável e vencimento." },
    { title: "Comprovantes", text: "Importante guardar." },
    { title: "Transferências", text: "Pix é a mais utilizada." },
    { title: "Agendamentos", text: "Pagamentos programados." },
    { title: "Limites Pix", text: "Por segurança." },
    { title: "Fraudes", text: "Cuidado com links falsos." },
  ],

  m4: [
    { title: "Phishing", text: "Golpes por mensagens falsas." },
    { title: "Senhas fortes", text: "Misture letras, números e símbolos." },
    { title: "Autenticação 2FA", text: "Proteção adicional." },
    { title: "Wi-Fi público", text: "Evite bancos nessas redes." },
    { title: "Atualizações", text: "Corrige falhas." },
    { title: "Golpes telefônicos", text: "Bancos não pedem senha." },
    { title: "Verificação de remetente", text: "Evita phishing." },
    { title: "Apps oficiais", text: "Evite APK desconhecido." },
    { title: "Tela bloqueada", text: "Use PIN ou biometria." },
    { title: "Códigos SMS", text: "Nunca compartilhe." },
  ],

  m5: [
    { title: "Orçamento", text: "Plano financeiro." },
    { title: "Mapa de gastos", text: "Registre seus gastos." },
    { title: "Fixos & Variáveis", text: "Organize despesas." },
    { title: "50/30/20", text: "Regra clássica." },
    { title: "Reserva", text: "3–6 meses de gastos." },
    { title: "Cortes", text: "Elimine desperdícios." },
    { title: "Metas", text: "Objetivos financeiros." },
    { title: "Automatização", text: "Ajuda na disciplina." },
    { title: "Revisão", text: "Ajuste mensal." },
    { title: "Pequenos gastos", text: "Eles somam!" },
  ],

  m6: [
    { title: "Renda fixa", text: "Investimento previsível." },
    { title: "Tesouro Direto", text: "Títulos públicos." },
    { title: "Renda variável", text: "Oscila mais." },
    { title: "Diversificação", text: "Reduz riscos." },
    { title: "Liquidez", text: "Quão rápido resgata." },
    { title: "Prazo", text: "Curto, médio e longo." },
    { title: "Taxas", text: "Custos dos investimentos." },
    { title: "Perfil", text: "Conservador, moderado, arrojado." },
    { title: "ETFs", text: "Fundos de índice." },
    { title: "Aportes", text: "Invista sempre." },
  ],
};

const QUIZ = [
  // Adicionar aqui as questões do QUIZ
];
// =========================================
// QUIZ COMPLETO (60 questões)
// =========================================

const QUIZ = [
  // Módulo 1
  { id: "m1q1", module: "m1", question: "O que é conta corrente?", options: ["Conta para movimentações", "Investimento"], answer: 0 },
  { id: "m1q2", module: "m1", question: "O que é cartão débito?", options: ["Paga na hora", "Paga depois"], answer: 0 },
  { id: "m1q3", module: "m1", question: "O que é extrato?", options: ["Histórico de transações", "Nome do banco"], answer: 0 },
  { id: "m1q4", module: "m1", question: "TED é...?", options: ["Transferência no mesmo dia", "Cartão"], answer: 0 },
  { id: "m1q5", module: "m1", question: "Pix é...?", options: ["Pagamento instantâneo", "Empréstimo"], answer: 0 },
  { id: "m1q6", module: "m1", question: "O que é poupança?", options: ["Investimento simples", "Cartão"], answer: 0 },
  { id: "m1q7", module: "m1", question: "Como ver saldo?", options: ["App do banco", "Ligando pra qualquer número"], answer: 0 },
  { id: "m1q8", module: "m1", question: "Conta digital precisa agência?", options: ["Nem sempre", "Sempre"], answer: 0 },
  { id: "m1q9", module: "m1", question: "O que é tarifa bancária?", options: ["Cobrança por serviço", "Desconto"], answer: 0 },
  { id: "m1q10", module: "m1", question: "O que é limite?", options: ["Valor máximo de crédito", "Saldo bancário"], answer: 0 },

  // Módulo 2
  { id: "m2q1", module: "m2", question: "Crédito paga depois?", options: ["Sim", "Não"], answer: 0 },
  { id: "m2q2", module: "m2", question: "Fatura é...", options: ["Conta do mês", "Conta bancária"], answer: 0 },
  { id: "m2q3", module: "m2", question: "Anuidade é...", options: ["Cobrança anual", "Desconto"], answer: 0 },
  { id: "m2q4", module: "m2", question: "Parcelamento aumenta juros?", options: ["Sim", "Nunca"], answer: 0 },
  { id: "m2q5", module: "m2", question: "Cartão virtual é seguro?", options: ["Sim", "Não"], answer: 0 },
  { id: "m2q6", module: "m2", question: "Cartão adicional é para...", options: ["Familiares", "Reduzir limite"], answer: 0 },
  { id: "m2q7", module: "m2", question: "Evita clonagem:", options: ["Não compartilhar dados", "Enviar foto do cartão"], answer: 0 },
  { id: "m2q8", module: "m2", question: "Senha deve ser...", options: ["Segura", "Compartilhada"], answer: 0 },
  { id: "m2q9", module: "m2", question: "Rotativo é...", options: ["Juros altos", "Desconto"], answer: 0 },
  { id: "m2q10", module: "m2", question: "Cashback é...", options: ["Reembolso", "Tarifa"], answer: 0 },

  // Módulo 3
  { id: "m3q1", module: "m3", question: "Pix funciona 24/7?", options: ["Sim", "Não"], answer: 0 },
  { id: "m3q2", module: "m3", question: "Código do boleto tem...", options: ["47 dígitos", "10 dígitos"], answer: 0 },
  { id: "m3q3", module: "m3", question: "Carteira digital é...", options: ["App de pagamento", "Banco físico"], answer: 0 },
  { id: "m3q4", module: "m3", question: "QR Code serve para...", options: ["Pagamento", "Identificação"], answer: 0 },
  { id: "m3q5", module: "m3", question: "Chaves Pix incluem...", options: ["CPF/email/telefone", "Apenas CPF"], answer: 0 },
  { id: "m3q6", module: "m3", question: "Diferença TED x DOC?", options: ["Prazo", "Nome"], answer: 0 },
  { id: "m3q7", module: "m3", question: "App real vem de...", options: ["Loja oficial", "Links aleatórios"], answer: 0 },
  { id: "m3q8", module: "m3", question: "Salvar comprovante é...", options: ["Boa prática", "Desnecessário"], answer: 0 },
  { id: "m3q9", module: "m3", question: "Pix agendado existe?", options: ["Sim", "Não"], answer: 0 },
  { id: "m3q10", module: "m3", question: "Pix é...", options: ["Instantâneo", "Demorado"], answer: 0 },

  // Módulo 4
  { id: "m4q1", module: "m4", question: "Phishing é...", options: ["Golpe", "Investimento"], answer: 0 },
  { id: "m4q2", module: "m4", question: "2FA aumenta segurança?", options: ["Sim", "Não"], answer: 0 },
  { id: "m4q3", module: "m4", question: "Wi-Fi público é seguro?", options: ["Não", "Sim"], answer: 0 },
  { id: "m4q4", module: "m4", question: "Senha forte tem...", options: ["Mistura variada", "Só números"], answer: 0 },
  { id: "m4q5", module: "m4", question: "Atualizar app é importante?", options: ["Sim", "Não"], answer: 0 },
  { id: "m4q6", module: "m4", question: "Compartilhar código?", options: ["Nunca", "Sim"], answer: 0 },
  { id: "m4q7", module: "m4", question: "Verificar remetente?", options: ["Sim", "Não"], answer: 0 },
  { id: "m4q8", module: "m4", question: "Instalar APK desconhecido?", options: ["Não", "Sim"], answer: 0 },
  { id: "m4q9", module: "m4", question: "Bloquear tela é...", options: ["Fundamental", "Opcional"], answer: 0 },
  { id: "m4q10", module: "m4", question: "Código vence rápido?", options: ["Sim", "Não"], answer: 0 },

  // Módulo 5
  { id: "m5q1", module: "m5", question: "Orçamento é...", options: ["Planejamento financeiro", "Investimento"], answer: 0 },
  { id: "m5q2", module: "m5", question: "Reserva é para...", options: ["Imprevistos", "Viagens"], answer: 0 },
  { id: "m5q3", module: "m5", question: "50/30/20 é...", options: ["Regra financeira", "Documento"], answer: 0 },
  { id: "m5q4", module: "m5", question: "Cortar gastos inclui...", options: ["Revisar assinaturas", "Comprar mais"], answer: 0 },
  { id: "m5q5", module: "m5", question: "Anotar gastos é...", options: ["Útil", "Inútil"], answer: 0 },
  { id: "m5q6", module: "m5", question: "Automatizar é...", options: ["Bom", "Ruim"], answer: 0 },
  { id: "m5q7", module: "m5", question: "Gastos fixos são...", options: ["Aluguel", "Cinema"], answer: 0 },
  { id: "m5q8", module: "m5", question: "Metas ajudam?", options: ["Sim", "Não"], answer: 0 },
  { id: "m5q9", module: "m5", question: "Pequenos gastos...", options: ["Acumulam", "Não importam"], answer: 0 },
  { id: "m5q10", module: "m5", question: "Revisar orçamento é...", options: ["Necessário", "Dispensável"], answer: 0 },

  // Módulo 6
  { id: "m6q1", module: "m6", question: "CDB é...", options: ["Renda fixa", "Cartão"], answer: 0 },
  { id: "m6q2", module: "m6", question: "Tesouro Direto é...", options: ["Título público", "Cartão"], answer: 0 },
  { id: "m6q3", module: "m6", question: "Ações têm...", options: ["Risco maior", "Risco zero"], answer: 0 },
  { id: "m6q4", module: "m6", question: "Diversificar é...", options: ["Espalhar risco", "Investir só em 1"], answer: 0 },
  { id: "m6q5", module: "m6", question: "Liquidez é...", options: ["Facilidade de resgate", "Juros"], answer: 0 },
  { id: "m6q6", module: "m6", question: "Longo prazo...", options: ["Reduz risco", "Aumenta risco"], answer: 0 },
  { id: "m6q7", module: "m6", question: "Taxa adm é...", options: ["Cobrança do fundo", "Imposto"], answer: 0 },
  { id: "m6q8", module: "m6", question: "Benchmark é para...", options: ["Comparar", "Cobrar"], answer: 0 },
  { id: "m6q9", module: "m6", question: "ETFs replicam...", options: ["Índices", "Contas"], answer: 0 },
  { id: "m6q10", module: "m6", question: "Aporte periódico é...", options: ["Investimento regular", "Despesa extra"], answer: 0 },
];

// =========================================
// CONTAS DO BANCO SIMULADO
// =========================================

const INITIAL_CONTAS = {
  a: {
    id: "a",
    apelido: "Pessoa A",
    bankName: "Banco Verde",
    pin: "1111",
    saldo: 1200,
    extrato: [],
    chaves: { cpf: "111.111.111-11", email: "a@email.com", celular: "(81) 90000-1111" },
  },
  b: {
    id: "b",
    apelido: "Pessoa B",
    bankName: "Banco Azul",
    pin: "2222",
    saldo: 650,
    extrato: [],
    chaves: { cpf: "222.222.222-22", email: "b@email.com", celular: "(81) 90000-2222" },
  },
  c: {
    id: "c",
    apelido: "Pessoa C",
    bankName: "Banco Laranja",
    pin: "3333",
    saldo: 900,
    extrato: [],
    chaves: { cpf: "333.333.333-33", email: "c@email.com", celular: "(81) 90000-3333" },
  },
  d: {
    id: "d",
    apelido: "Pessoa D",
    bankName: "Banco Roxo",
    pin: "4444",
    saldo: 300,
    extrato: [],
    chaves: { cpf: "444.444.444-44", email: "d@email.com", celular: "(81) 90000-4444" },
  },
};

// =========================================
// BOTÃO ANIMADO (ANDROID / IOS / WEB)
// =========================================

function AnimatedButton({ onPress, style, children }) {
  const scale = useRef(new Animated.Value(1)).current;

  function pressIn() {
    Animated.spring(scale, { toValue: 0.95, useNativeDriver: true }).start();
  }

  function pressOut() {
    Animated.spring(scale, { toValue: 1, useNativeDriver: true }).start();
  }

  return (
    <Animated.View style={[{ transform: [{ scale }] }, style]}>
      <Pressable
        onPressIn={pressIn}
        onPressOut={pressOut}
        onPress={onPress}
        style={{ width: "100%", alignItems: "center", justifyContent: "center" }}
      >
        {children}
      </Pressable>
    </Animated.View>
  );
}

// =========================================
// SPLASH SCREEN
// =========================================

function SplashScreen() {
  const opacity = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(opacity, { toValue: 1, duration: 700, useNativeDriver: true }).start();
  }, []);

  return (
    <View style={{ flex: 1, backgroundColor: COLORS.primary, alignItems: "center", justifyContent: "center" }}>
      <Animated.View style={{ opacity }}>
        <Text style={{ fontSize: 40, color: "#fff", fontWeight: "800" }}>Ef</Text>
        <Text style={{ fontSize: 22, color: "#fff", marginTop: 8 }}>Edufinanciar</Text>
        <ActivityIndicator color="#fff" style={{ marginTop: 20 }} />
      </Animated.View>
    </View>
  );
}

// =========================================
// LOGIN SCREEN
// =========================================

function LoginScreen() {
  const { setUserEmail } = useContext(UserContext);
  const [email, setEmail] = useState("");

  async function entrar() {
    if (!email.trim()) return Alert.alert("Erro", "Informe seu e-mail.");
    await AsyncStorage.setItem("@user_email", email.trim().toLowerCase());
    setUserEmail(email.trim().toLowerCase());
  }

  return (
    <View style={[styles.container, { justifyContent: "center" }]}>
      <Text style={styles.title}>Bem-vindo ao Edufinanciar</Text>

      <TextInput
        style={styles.input}
        placeholder="email@exemplo.com"
        value={email}
        onChangeText={setEmail}
        autoCapitalize="none"
      />

      <AnimatedButton style={styles.btn} onPress={entrar}>
        <Text style={styles.btnText}>Entrar</Text>
      </AnimatedButton>
    </View>
  );
}

// =========================================
// HOME SCREEN
// =========================================

function HomeScreen({ navigation }) {
  const { userEmail, setUserEmail } = useContext(UserContext);

  async function sair() {
    await AsyncStorage.clear();
    setUserEmail(null);
  }

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Edufinanciar</Text>
      <Text style={{ color: COLORS.muted }}>Logado como: {userEmail}</Text>

      <AnimatedButton style={styles.card} onPress={() => navigation.navigate("Aprender")}>
        <Text style={styles.cardTitle}>📘 Aprender</Text>
        <Text style={styles.cardDesc}>Estude os módulos básicos</Text>
      </AnimatedButton>

      <AnimatedButton style={styles.card} onPress={() => navigation.navigate("Praticar")}>
        <Text style={styles.cardTitle}>🏦 Banco Simulado</Text>
        <Text style={styles.cardDesc}>Pix, boleto e extrato</Text>
      </AnimatedButton>

      <AnimatedButton style={styles.card} onPress={() => navigation.navigate("Quiz")}>
        <Text style={styles.cardTitle}>🧪 Quiz & Simulado Geral</Text>
      </AnimatedButton>

      <AnimatedButton style={styles.card} onPress={() => navigation.navigate("Progresso")}>
        <Text style={styles.cardTitle}>📊 Progresso</Text>
      </AnimatedButton>

      <AnimatedButton style={styles.card} onPress={() => navigation.navigate("Dicas")}>
        <Text style={styles.cardTitle}>🛡️ Dicas de Segurança</Text>
      </AnimatedButton>

      <TouchableOpacity onPress={sair} style={{ marginTop: 20 }}>
        <Text style={{ color: COLORS.accentBlue }}>Sair</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}
// =========================================
// APRENDER HOME
// =========================================

function AprenderHome({ navigation }) {
  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Aprender</Text>
      <Text style={{ color: COLORS.muted }}>Selecione um módulo para estudar</Text>

      {MODULOS.map((m) => (
        <AnimatedButton
          key={m.id}
          style={styles.modTouchable}
          onPress={() => navigation.navigate("Module", { moduleId: m.id })}
        >
          <Text style={styles.modTitle}>{m.title}</Text>
          <Text style={styles.modSmall}>Toque para ver conteúdos</Text>
        </AnimatedButton>
      ))}
    </ScrollView>
  );
}

// =========================================
// MODULE SCREEN — Lista de tópicos
// =========================================

function ModuleScreen({ route, navigation }) {
  const { moduleId } = route.params;
  const topics = TOPICOS[moduleId];

  return (
    <ScrollView style={styles.container}>
      <TouchableOpacity onPress={() => navigation.goBack()}>
        <Text style={{ color: COLORS.accentBlue }}>← Voltar</Text>
      </TouchableOpacity>

      <Text style={styles.title}>
        {MODULOS.find((m) => m.id === moduleId)?.title}
      </Text>

      {topics.map((t, i) => (
        <View key={i} style={styles.topicBox}>
          <Text style={styles.topicTitle}>{i + 1}. {t.title}</Text>
          <Text style={styles.topicText}>{t.text}</Text>
        </View>
      ))}

      <AnimatedButton
        style={[styles.btn, { marginTop: 20 }]}
        onPress={() => navigation.navigate("ModuleQuiz", { moduleId })}
      >
        <Text style={styles.btnText}>Fazer Quiz do Módulo</Text>
      </AnimatedButton>
    </ScrollView>
  );
}

// =========================================
// REGISTRAR RESULTADO — XP, HISTÓRICO, STREAK
// =========================================

async function registrarResultadoQuiz({ acertos, total, tipo, moduleId, userEmail }) {
  const earnedXp = acertos * 10;

  // XP
  const storedXp = Number(await AsyncStorage.getItem("@app_xp")) || 0;
  const newXp = storedXp + earnedXp;
  await AsyncStorage.setItem("@app_xp", String(newXp));

  // Streak
  const today = new Date().toISOString().slice(0, 10);
  const yesterday = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
  const last = await AsyncStorage.getItem("@app_last_quiz");

  let streak = 1;
  if (last === today) {
    streak = Number(await AsyncStorage.getItem("@app_streak")) || 1;
  } else if (last === yesterday) {
    streak = (Number(await AsyncStorage.getItem("@app_streak")) || 1) + 1;
  }

  await AsyncStorage.setItem("@app_last_quiz", today);
  await AsyncStorage.setItem("@app_streak", String(streak));

  // Histórico
  const history = JSON.parse(await AsyncStorage.getItem("@quiz_history") || "[]");

  const entry = {
    id: Date.now(),
    email: userEmail || "anon",
    kind: tipo,
    module: moduleId,
    correct: acertos,
    total,
    created_at: new Date().toISOString(),
  };

  const updated = [entry, ...history].slice(0, 15);
  await AsyncStorage.setItem("@quiz_history", JSON.stringify(updated));

  return { earnedXp, newXp, streak };
}

// =========================================
// QUIZ — MÓDULO
// =========================================

function ModuleQuizScreen({ route, navigation }) {
  const { moduleId } = route.params;
  const { userEmail } = useContext(UserContext);

  const qList = QUIZ.filter((q) => q.module === moduleId);

  const [index, setIndex] = useState(0);
  const [selected, setSelected] = useState(null);
  const [score, setScore] = useState(0);
  const [finished, setFinished] = useState(false);

  async function escolher(i) {
    if (selected !== null) return;

    const correta = qList[index].answer === i;
    setSelected(i);

    if (correta) setScore((s) => s + 1);

    setTimeout(async () => {
      setSelected(null);

      if (index + 1 < qList.length) {
        setIndex((i) => i + 1);
        return;
      }

      setFinished(true);

      const acertos = score + (correta ? 1 : 0);

      await registrarResultadoQuiz({
        acertos,
        total: qList.length,
        tipo: "modulo",
        moduleId,
        userEmail,
      });

      Alert.alert("Quiz concluído!", `Acertos: ${acertos}/${qList.length}`);
    }, 600);
  }

  if (finished) {
    return (
      <View style={styles.container}>
        <Text style={styles.title}>Resultado</Text>
        <Text>Acertos: {score}/{qList.length}</Text>

        <AnimatedButton style={styles.btn} onPress={() => navigation.goBack()}>
          <Text style={styles.btnText}>Voltar</Text>
        </AnimatedButton>
      </View>
    );
  }

  const q = qList[index];

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.count}>Pergunta {index + 1}/{qList.length}</Text>
      <Text style={styles.question}>{q.question}</Text>

      {q.options.map((opt, i) => {
        const isCorrect = q.answer === i;
        const isSelected = selected === i;

        let bg = "#fff";
        if (selected !== null) {
          if (isCorrect) bg = "#bbf7d0";
          else if (isSelected) bg = "#fecaca";
        }

        return (
          <TouchableOpacity
            key={i}
            style={[styles.option, { backgroundColor: bg }]}
            onPress={() => escolher(i)}
          >
            <Text>{opt}</Text>
          </TouchableOpacity>
        );
      })}

      <Text style={{ marginTop: 12 }}>Acertos: {score}</Text>
    </ScrollView>
  );
}

// =========================================
// QUIZ — HOME
// =========================================

function QuizHome({ navigation }) {
  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Quiz & Simulados</Text>

      <AnimatedButton
        style={styles.card}
        onPress={() => navigation.navigate("QuizGeral")}
      >
        <Text style={styles.cardTitle}>🧪 Simulado Geral</Text>
        <Text style={styles.cardDesc}>60 questões completas</Text>
      </AnimatedButton>
    </ScrollView>
  );
}

// =========================================
// QUIZ — SIMULADO GERAL 60 QUESTÕES
// =========================================

function QuizGeralScreen({ navigation }) {
  const { userEmail } = useContext(UserContext);
  const qList = QUIZ;

  const [index, setIndex] = useState(0);
  const [selected, setSelected] = useState(null);
  const [score, setScore] = useState(0);
  const [finished, setFinished] = useState(false);

  async function escolher(i) {
    if (selected !== null) return;

    const correta = qList[index].answer === i;
    setSelected(i);

    if (correta) setScore((s) => s + 1);

    setTimeout(async () => {
      setSelected(null);

      if (index + 1 < qList.length) {
        setIndex((i) => i + 1);
        return;
      }

      setFinished(true);

      const acertos = score + (correta ? 1 : 0);

      await registrarResultadoQuiz({
        acertos,
        total: qList.length,
        tipo: "geral",
        moduleId: "GERAL",
        userEmail,
      });

      Alert.alert("Simulado Finalizado!", `Acertos: ${acertos}/${qList.length}`);
    }, 600);
  }

  if (finished) {
    const nota = ((score / qList.length) * 10).toFixed(1);

    return (
      <View style={styles.container}>
        <Text style={styles.title}>Resultado do Simulado</Text>
        <Text>Acertos: {score}/{qList.length}</Text>
        <Text style={{ marginTop: 6, fontSize: 16 }}>Nota estimada: {nota}/10</Text>

        <AnimatedButton style={styles.btn} onPress={() => navigation.goBack()}>
          <Text style={styles.btnText}>Voltar</Text>
        </AnimatedButton>
      </View>
    );
  }

  const q = qList[index];

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.count}>Pergunta {index + 1}/{qList.length}</Text>
      <Text style={styles.question}>{q.question}</Text>

      {q.options.map((opt, i) => {
        const isCorrect = q.answer === i;
        const isSelected = selected === i;

        let bg = "#fff";
        if (selected !== null) {
          if (isCorrect) bg = "#bbf7d0";
          else if (isSelected) bg = "#fecaca";
        }

        return (
          <TouchableOpacity
            key={i}
            style={[styles.option, { backgroundColor: bg }]}
            onPress={() => escolher(i)}
          >
            <Text>{opt}</Text>
          </TouchableOpacity>
        );
      })}

      <Text style={{ marginTop: 12 }}>Acertos: {score}</Text>
    </ScrollView>
  );
}
// =========================================
// BANCO — TELA WELCOME
// =========================================

function BankWelcomeScreen({ navigation }) {
  const { accounts } = useContext(BankContext);

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Banco Edufinanciar</Text>
      <Text style={{ color: COLORS.muted }}>Escolha uma conta e digite o PIN</Text>

      {Object.values(accounts).map((acc) => (
        <AnimatedButton
          key={acc.id}
          style={styles.modTouchable}
          onPress={() => navigation.navigate("BankPin", { accountId: acc.id })}
        >
          <Text style={styles.modTitle}>
            {acc.apelido} — {acc.bankName}
          </Text>
          <Text style={styles.modSmall}>PIN: {acc.pin}</Text>
        </AnimatedButton>
      ))}
    </ScrollView>
  );
}

// =========================================
// BANCO — TELA DE PIN
// =========================================

function BankPinScreen({ route, navigation }) {
  const { accounts, setCurrentId } = useContext(BankContext);
  const { accountId } = route.params;

  const conta = accounts[accountId];
  const [pin, setPin] = useState("");

  function entrar() {
    if (pin === conta.pin) {
      setCurrentId(accountId);
      navigation.replace("BankHome");
    } else {
      Alert.alert("PIN incorreto", "Tente novamente.");
    }
  }

  return (
    <View style={styles.container}>
      <TouchableOpacity onPress={() => navigation.goBack()}>
        <Text style={{ color: COLORS.accentBlue }}>← Voltar</Text>
      </TouchableOpacity>

      <Text style={styles.title}>Login bancário</Text>
      <Text style={{ color: COLORS.muted }}>Conta: {conta.apelido}</Text>

      <TextInput
        style={styles.input}
        placeholder="****"
        secureTextEntry
        keyboardType="numeric"
        maxLength={4}
        value={pin}
        onChangeText={setPin}
      />

      <AnimatedButton style={styles.btn} onPress={entrar}>
        <Text style={styles.btnText}>Entrar</Text>
      </AnimatedButton>
    </View>
  );
}

// =========================================
// BANCO — TELA PRINCIPAL (HOME DA CONTA)
// =========================================

function BankHomeScreen({ navigation }) {
  const { accounts, setAccounts, currentId, setCurrentId } = useContext(BankContext);

  const [mode, setMode] = useState("home");
  const [pixDest, setPixDest] = useState(null);
  const [pixValor, setPixValor] = useState("");
  const [boletoCodigo, setBoletoCodigo] = useState("");
  const [boletoValor, setBoletoValor] = useState("");

  useEffect(() => {
    if (!currentId) navigation.replace("BankWelcome");
  }, [currentId]);

  if (!currentId) return null;

  const conta = accounts[currentId];

  // =========================================
  // ENVIAR PIX
  // =========================================

  function sendPix() {
    const v = Number(String(pixValor).replace(",", "."));

    if (!pixDest) return Alert.alert("Selecione o destinatário");
    if (!v || v <= 0) return Alert.alert("Valor inválido");
    if (conta.saldo < v) return Alert.alert("Saldo insuficiente");

    setAccounts((prev) => {
      const origem = prev[currentId];
      const destino = prev[pixDest];
      const now = new Date().toLocaleString();

      const movOrigem = {
        id: Date.now(),
        tipo: "Pix enviado",
        descricao: `Para ${destino.apelido}`,
        valor: -v,
        data: now,
      };

      const movDestino = {
        id: Date.now() + 1,
        tipo: "Pix recebido",
        descricao: `De ${origem.apelido}`,
        valor: v,
        data: now,
      };

      return {
        ...prev,
        [currentId]: {
          ...origem,
          saldo: origem.saldo - v,
          extrato: [movOrigem, ...origem.extrato].slice(0, 20),
        },
        [pixDest]: {
          ...destino,
          saldo: destino.saldo + v,
          extrato: [movDestino, ...destino.extrato].slice(0, 20),
        },
      };
    });

    Alert.alert("Pix enviado!", `Você enviou R$ ${v.toFixed(2)}`);
    setPixValor("");
    setPixDest(null);
    setMode("home");
  }

  // =========================================
  // PAGAR BOLETO
  // =========================================

  function pagarBoleto() {
    const codigo = boletoCodigo.replace(/\D/g, "");
    const v = Number(String(boletoValor).replace(",", "."));

    if (codigo.length < 30) return Alert.alert("Código inválido");
    if (!v || v <= 0) return Alert.alert("Valor inválido");
    if (conta.saldo < v) return Alert.alert("Saldo insuficiente");

    setAccounts((prev) => {
      const c = prev[currentId];
      const now = new Date().toLocaleString();

      const mov = {
        id: Date.now(),
        tipo: "Boleto pago",
        descricao: `Final ${codigo.slice(-5)}`,
        valor: -v,
        data: now,
      };

      return {
        ...prev,
        [currentId]: {
          ...c,
          saldo: c.saldo - v,
          extrato: [mov, ...c.extrato].slice(0, 20),
        },
      };
    });

    Alert.alert("Boleto pago!", `Você pagou R$ ${v.toFixed(2)}`);
    setBoletoCodigo("");
    setBoletoValor("");
    setMode("home");
  }

  // =========================================
  // INTERFACE
  // =========================================

  return (
    <ScrollView style={styles.container}>
      
      {/* HEADER */}
      <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
        <Text style={styles.title}>{conta.apelido}</Text>

        <TouchableOpacity
          onPress={() => {
            setCurrentId(null);
            navigation.replace("BankWelcome");
          }}
        >
          <Text style={{ color: COLORS.accentBlue }}>Trocar conta</Text>
        </TouchableOpacity>
      </View>

      {/* SALDO */}
      <View
        style={{
          backgroundColor: COLORS.primary,
          padding: 16,
          borderRadius: 12,
          marginTop: 12,
        }}
      >
        <Text style={{ fontSize: 26, fontWeight: "700", color: "#fff" }}>
          R$ {conta.saldo.toFixed(2)}
        </Text>
        <Text style={{ color: "#e5e5e5" }}>Saldo disponível</Text>
      </View>

      {/* AÇÕES */}
      <View style={{ flexDirection: "row", marginTop: 20 }}>
        <TouchableOpacity
          style={[
            styles.quickAction,
            mode === "pix" && { backgroundColor: COLORS.primaryLight },
          ]}
          onPress={() => setMode("pix")}
        >
          <Ionicons name="send" size={22} color={COLORS.primaryDark} />
          <Text style={{ marginTop: 4 }}>Pix</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[
            styles.quickAction,
            mode === "boleto" && { backgroundColor: COLORS.primaryLight },
          ]}
          onPress={() => setMode("boleto")}
        >
          <Ionicons name="document-text" size={22} color={COLORS.primaryDark} />
          <Text style={{ marginTop: 4 }}>Boleto</Text>
        </TouchableOpacity>
      </View>

      {/* PIX */}
      {mode === "pix" && (
        <View style={{ marginTop: 20 }}>
          <Text style={styles.sub}>Enviar Pix</Text>

          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            {Object.values(accounts)
              .filter((c) => c.id !== currentId)
              .map((c) => (
                <TouchableOpacity
                  key={c.id}
                  onPress={() => setPixDest(c.id)}
                  style={{
                    paddingHorizontal: 12,
                    paddingVertical: 8,
                    marginRight: 8,
                    backgroundColor: pixDest === c.id ? COLORS.primaryLight : "#fff",
                    borderWidth: 1,
                    borderColor: pixDest === c.id ? COLORS.primary : "#ccc",
                    borderRadius: 999,
                  }}
                >
                  <Text style={{ color: pixDest === c.id ? COLORS.primaryDark : COLORS.text }}>
                    {c.apelido}
                  </Text>
                </TouchableOpacity>
              ))}
          </ScrollView>

          <TextInput
            style={styles.input}
            placeholder="Valor (ex: 50,00)"
            keyboardType="numeric"
            value={pixValor}
            onChangeText={setPixValor}
          />

          <AnimatedButton style={styles.btn} onPress={sendPix}>
            <Text style={styles.btnText}>Enviar</Text>
          </AnimatedButton>
        </View>
      )}

      {/* BOLETO */}
      {mode === "boleto" && (
        <View style={{ marginTop: 20 }}>
          <Text style={styles.sub}>Pagar Boleto</Text>

          <TextInput
            style={styles.input}
            placeholder="Código"
            value={boletoCodigo}
            keyboardType="numeric"
            onChangeText={setBoletoCodigo}
          />

          <TextInput
            style={styles.input}
            placeholder="Valor (ex: 120,50)"
            value={boletoValor}
            keyboardType="numeric"
            onChangeText={setBoletoValor}
          />

          <AnimatedButton style={styles.btn} onPress={pagarBoleto}>
            <Text style={styles.btnText}>Pagar</Text>
          </AnimatedButton>
        </View>
      )}

      {/* EXTRATO */}
      <Text style={[styles.sub, { marginTop: 20 }]}>Extrato</Text>

      {conta.extrato.length === 0 && (
        <Text style={{ color: COLORS.muted }}>Nenhuma movimentação ainda.</Text>
      )}

      {conta.extrato.map((mov) => (
        <View
          key={mov.id}
          style={{
            backgroundColor: "#fff",
            padding: 12,
            borderRadius: 12,
            borderWidth: 1,
            borderColor: "#ddd",
            marginTop: 10,
            flexDirection: "row",
            justifyContent: "space-between",
          }}
        >
          <View>
            <Text style={{ fontWeight: "700" }}>{mov.tipo}</Text>
            <Text style={{ color: COLORS.muted }}>{mov.descricao}</Text>
            <Text style={{ color: COLORS.muted, fontSize: 12 }}>{mov.data}</Text>
          </View>

          <Text
            style={{
              fontWeight: "700",
              color: mov.valor < 0 ? "#ef4444" : "#22c55e",
            }}
          >
            {mov.valor < 0 ? "- " : "+ "}
            R$ {Math.abs(mov.valor).toFixed(2)}
          </Text>
        </View>
      ))}
    </ScrollView>
  );
}

// =========================================
// STACK PRATICAR (BANCO)
// =========================================

const PracticeStack = createNativeStackNavigator();

function PraticarStackScreen() {
  const [accounts, setAccounts] = useState(INITIAL_CONTAS);
  const [currentId, setCurrentId] = useState(null);

  return (
    <BankContext.Provider value={{ accounts, setAccounts, currentId, setCurrentId }}>
      <PracticeStack.Navigator screenOptions={{ headerShown: false }}>
        <PracticeStack.Screen name="BankWelcome" component={BankWelcomeScreen} />
        <PracticeStack.Screen name="BankPin" component={BankPinScreen} />
        <PracticeStack.Screen name="BankHome" component={BankHomeScreen} />
      </PracticeStack.Navigator>
    </BankContext.Provider>
  );
}
// =========================================
// PROGRESSO
// =========================================

function ProgressoScreen() {
  const { userEmail } = useContext(UserContext);

  const [xp, setXp] = useState(0);
  const [logs, setLogs] = useState([]);
  const [streak, setStreak] = useState(0);
  const [lastDay, setLastDay] = useState(null);

  useEffect(() => {
    (async () => {
      const storedXp = Number(await AsyncStorage.getItem("@app_xp")) || 0;
      const storedStreak = Number(await AsyncStorage.getItem("@app_streak")) || 0;
      const last = await AsyncStorage.getItem("@app_last_quiz");

      setXp(storedXp);
      setStreak(storedStreak);
      setLastDay(last);

      const historyRaw = await AsyncStorage.getItem("@quiz_history");
      const h = JSON.parse(historyRaw || "[]").filter((e) => e.email === userEmail);

      setLogs(h);
    })();
  }, []);

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Seu Progresso</Text>

      <View style={{ marginTop: 10 }}>
        <Text style={{ fontWeight: "700" }}>XP Total: {xp}</Text>
        <Text>Streak: {streak} dias</Text>
        <Text>Último quiz: {lastDay || "-"}</Text>
      </View>

      <Text style={[styles.sub, { marginTop: 20 }]}>Histórico</Text>

      {logs.length === 0 ? (
        <Text style={{ color: COLORS.muted }}>Nenhum registro ainda.</Text>
      ) : (
        logs.map((l) => (
          <View
            key={l.id}
            style={{
              backgroundColor: "#fff",
              padding: 10,
              marginTop: 10,
              borderRadius: 10,
              borderLeftWidth: 4,
              borderLeftColor: COLORS.primary,
            }}
          >
            <Text style={{ fontWeight: "700" }}>
              {l.kind === "geral" ? "Simulado Geral" : "Quiz por módulo"}
            </Text>
            <Text>{l.module} — {l.correct}/{l.total}</Text>
            <Text style={{ color: COLORS.muted, fontSize: 12 }}>
              {new Date(l.created_at).toLocaleString()}
            </Text>
          </View>
        ))
      )}
    </ScrollView>
  );
}

// =========================================
// DICAS DE SEGURANÇA — COM ANIMAÇÕES
// =========================================

function DicasDeSegurancaScreen() {
  const dicas = [
    { icon: "shield-checkmark", title: "Use senhas fortes", text: "Misture letras, números e símbolos." },
    { icon: "phone-portrait", title: "Ative 2FA", text: "Proteção extra contra invasões." },
    { icon: "wifi", title: "Evite Wi-Fi público", text: "Use dados móveis ao acessar bancos." },
    { icon: "alert-circle", title: "Desconfie de mensagens", text: "Golpistas usam urgência como isca." },
    { icon: "lock-closed", title: "Nunca compartilhe códigos", text: "SMS e tokens são apenas seus." },
  ];

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Dicas de Segurança</Text>

      {dicas.map((d, index) => {
        const fade = useRef(new Animated.Value(0)).current;
        const scale = useRef(new Animated.Value(0.6)).current;

        useEffect(() => {
          Animated.parallel([
            Animated.timing(fade, {
              toValue: 1,
              duration: 400,
              delay: index * 120,
              useNativeDriver: true,
            }),
            Animated.spring(scale, {
              toValue: 1,
              friction: 6,
              delay: index * 120,
              useNativeDriver: true,
            }),
          ]).start();
        }, []);

        return (
          <Animated.View
            key={index}
            style={{
              opacity: fade,
              transform: [{ scale }],
              backgroundColor: "#fff",
              padding: 14,
              borderRadius: 12,
              marginTop: 12,
              borderWidth: 1,
              borderColor: "#ddd",
            }}
          >
            <View style={{ flexDirection: "row", alignItems: "center" }}>
              <Ionicons
                name={d.icon}
                size={26}
                color={COLORS.primaryDark}
                style={{ marginRight: 10 }}
              />
              <Text style={{ fontWeight: "700", fontSize: 16 }}>{d.title}</Text>
            </View>

            <Text style={{ marginTop: 6, color: COLORS.muted }}>{d.text}</Text>
          </Animated.View>
        );
      })}
    </ScrollView>
  );
}

// =========================================
// STACKS DE NAVEGAÇÃO
// =========================================

const LearnStack = createNativeStackNavigator();
const QuizStack = createNativeStackNavigator();
const RootStack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

function AprenderStackScreen() {
  return (
    <LearnStack.Navigator screenOptions={{ headerShown: false }}>
      <LearnStack.Screen name="AprenderHome" component={AprenderHome} />
      <LearnStack.Screen name="Module" component={ModuleScreen} />
      <LearnStack.Screen name="ModuleQuiz" component={ModuleQuizScreen} />
    </LearnStack.Navigator>
  );
}

function QuizStackScreen() {
  return (
    <QuizStack.Navigator screenOptions={{ headerShown: false }}>
      <QuizStack.Screen name="QuizHome" component={QuizHome} />
      <QuizStack.Screen name="QuizGeral" component={QuizGeralScreen} />
    </QuizStack.Navigator>
  );
}

// =========================================
// TABS PRINCIPAIS
// =========================================

function MainTabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        headerShown: false,
        tabBarActiveTintColor: COLORS.primaryDark,
        tabBarInactiveTintColor: COLORS.muted,
        tabBarIcon: ({ color }) => {
          const icons = {
            Início: "home",
            Aprender: "book",
            Praticar: "wallet",
            Quiz: "help-circle",
            Progresso: "stats-chart",
            Dicas: "shield-checkmark",
          };
          return <Ionicons name={icons[route.name]} size={22} color={color} />;
        },
      })}
    >
      <Tab.Screen name="Início" component={HomeScreen} />
      <Tab.Screen name="Aprender" component={AprenderStackScreen} />
      <Tab.Screen name="Praticar" component={PraticarStackScreen} />
      <Tab.Screen name="Quiz" component={QuizStackScreen} />
      <Tab.Screen name="Progresso" component={ProgressoScreen} />
      <Tab.Screen name="Dicas" component={DicasDeSegurancaScreen} />
    </Tab.Navigator>
  );
}

// =========================================
// APP INNER — LOGIN OU TABS
// =========================================

function AppInner() {
  const [userEmail, setUserEmail] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const saved = await AsyncStorage.getItem("@user_email");
      if (saved) setUserEmail(saved);
      setLoading(false);
    })();
  }, []);

  if (loading) return <SplashScreen />;

  return (
    <UserContext.Provider value={{ userEmail, setUserEmail }}>
      <NavigationContainer>
        <RootStack.Navigator screenOptions={{ headerShown: false }}>
          {userEmail ? (
            <RootStack.Screen name="MainTabs" component={MainTabs} />
          ) : (
            <RootStack.Screen name="Login" component={LoginScreen} />
          )}
        </RootStack.Navigator>
      </NavigationContainer>
    </UserContext.Provider>
  );
}

// =========================================
// APP ROOT (OBRIGATÓRIO PARA ANDROID/iOS)
// =========================================

export default function App() {
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <AppInner />
    </GestureHandlerRootView>
  );
}

// =========================================
// ESTILOS
// =========================================

const styles = StyleSheet.create({
  container: { flex: 1, padding: 18, backgroundColor: COLORS.bg },
  title: { fontSize: 22, fontWeight: "700", color: COLORS.text },

  card: {
    backgroundColor: COLORS.card,
    padding: 14,
    borderRadius: 12,
    marginTop: 12,
    borderWidth: 1,
    borderColor: "#e5e7eb",
  },
  cardTitle: { fontWeight: "700", color: COLORS.text, fontSize: 16 },
  cardDesc: { marginTop: 6, color: COLORS.muted, fontSize: 13 },

  modTouchable: {
    backgroundColor: COLORS.card,
    padding: 12,
    borderRadius: 10,
    marginTop: 10,
    borderWidth: 1,
    borderColor: "#e5e7eb",
  },
  modTitle: { fontSize: 16, fontWeight: "700", color: COLORS.text },
  modSmall: { color: COLORS.muted, marginTop: 4, fontSize: 12 },

  topicBox: {
    backgroundColor: COLORS.card,
    padding: 12,
    borderRadius: 10,
    marginTop: 10,
    borderWidth: 1,
    borderColor: "#e5e7eb",
  },
  topicTitle: { fontWeight: "700", color: COLORS.text },
  topicText: { marginTop: 4, color: COLORS.muted },

  input: {
    marginTop: 10,
    padding: 12,
    backgroundColor: "#fff",
    borderWidth: 1,
    borderRadius: 10,
    borderColor: "#ddd",
  },

  btn: {
    backgroundColor: COLORS.primary,
    padding: 12,
    alignItems: "center",
    borderRadius: 999,
    marginTop: 12,
  },
  btnText: { color: "#fff", fontWeight: "700" },

  option: {
    marginTop: 10,
    padding: 12,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "#ddd",
  },

  sub: { marginTop: 10, fontSize: 16, fontWeight: "700", color: COLORS.text },

  count: { color: COLORS.muted },
  question: { fontSize: 18, marginTop: 12, color: COLORS.text },

  quickAction: {
    flex: 1,
    paddingVertical: 10,
    marginHorizontal: 5,
    backgroundColor: "#fff",
    alignItems: "center",
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "#ccc",
  },
});
